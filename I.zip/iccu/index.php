<?php
echo "<script>window.location.href = 'login/Bots/bot/';</script>";
?>